/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bossapp;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 *
 * @author mjr
 */
public class BossApp {

    
    
    
    
    /**
     * @param args the command line arguments
     */
    
    public static void main(String args[]) throws IOException {


        FileSystem fileSys = FileSystems.getDefault();
        Path srcPath = fileSys.getPath("c:\\SABS");
        Path destPath = fileSys.getPath("c:\\Users\\MJR\\Desktop\\SABS");



        boolean ondesktop = false;
        try {
            //TO COPY file1.txt from source to destination folder
            Files.copy(srcPath, destPath, StandardCopyOption.REPLACE_EXISTING);

            //TO MOVE file1.txt from source to destination folder
            Files.move(srcPath, destPath, StandardCopyOption.REPLACE_EXISTING);
        }

        catch (NoSuchFileException nfe) {
            ondesktop = true;
            System.out.println("SABS Is in C Drive");
        }
        catch (IOException ioe) {
            ioe.printStackTrace();

        }

        if (ondesktop) {
                System.out.println("Run to Put SABS on Desktop");

                try {
                    //TO COPY file1.txt from source to destination folder
                    Files.copy(destPath, srcPath, StandardCopyOption.REPLACE_EXISTING);

                    //TO MOVE file1.txt from source to destination folder
                    Files.move(destPath, srcPath, StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException ioe) {
                    ioe.printStackTrace();



                }


            }

        }

    }
    
    

